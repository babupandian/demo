export const environment = {
    API_URL:'https://freeapi.miniprojectideas.com/api/ClientStrive/'
};
