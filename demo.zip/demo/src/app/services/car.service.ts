import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CarService {

  constructor() { }

  private carNamesSubject = new BehaviorSubject<string[]>([]);
  carNames$ = this.carNamesSubject.asObservable();
  
  addCarName(name: string) {
    const currentNames = this.carNamesSubject.getValue();
    const updateNames = [...currentNames, name]; //It will add the new value to the existing value
    this.carNamesSubject.next(updateNames);
  }

}
