import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Client } from '../model/class/Clients';
import { environment } from '../../environments/environment.development';
import { APIResponseModel } from '../model/interface/role';
import { Constants } from '../constant/Constants';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  constructor(private http: HttpClient) { }

 getAllClients():Observable<APIResponseModel>{
  return this.http.get<APIResponseModel>(environment.API_URL + Constants.API_METHOD.GET_ALL_CLIENT);
 } 

 getAllEmployee():Observable<APIResponseModel>{
  return this.http.get<APIResponseModel>(environment.API_URL + Constants.API_METHOD.GET_ALL_EMP);
 } 
 
 getAllClientProjects():Observable<APIResponseModel>{
  return this.http.get<APIResponseModel>(environment.API_URL + Constants.API_METHOD.GET_ALL_PROJ);
 } 

 addUpdate(obj: Client):Observable<APIResponseModel>{
  return this.http.post<APIResponseModel>(environment.API_URL + "AddUpdateClient",obj);
 } 

 deleteClientById(id:number):Observable<APIResponseModel>{
  return this.http.delete<APIResponseModel>(environment.API_URL + "DeleteClientByClientId?clientId="+id);
 } 

 addClientProjectUpdate(obj: Client):Observable<APIResponseModel>{
  return this.http.post<APIResponseModel>(environment.API_URL + "AddUpdateClientProject",obj);
 } 

//ASYN PIPE EXAMPLE instead of getting the values from ts directly we can get the values in html
getAllUser() {
  return this.http.get("https://jsonplaceholder.typicode.com/users");
}


}
