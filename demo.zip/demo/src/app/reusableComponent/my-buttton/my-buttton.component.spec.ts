import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyButttonComponent } from './my-buttton.component';

describe('MyButttonComponent', () => {
  let component: MyButttonComponent;
  let fixture: ComponentFixture<MyButttonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MyButttonComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyButttonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
