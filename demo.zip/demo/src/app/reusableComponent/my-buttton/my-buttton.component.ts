import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-my-buttton',
  standalone: true,
  imports: [],
  templateUrl: './my-buttton.component.html',
  styleUrl: './my-buttton.component.scss'
})
export class MyButttonComponent {

@Input() btnText: string ='';
@Input() btnClass: string ='';

@Output() onBtnClicked = new EventEmitter<any>();
textObject: object = {
  name: "babu", age: 27
}

onClick(){
  this.onBtnClicked.emit(this.textObject);//we can catch this admin text in parent comp $event
}

}
