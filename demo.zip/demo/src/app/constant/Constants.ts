export const Constants = {
    API_METHOD: {
        GET_ALL_EMP: 'GetAllClients',
        GET_ALL_CLIENT: 'GetAllEmployee',
        GET_ALL_PROJ: 'GetAllClientProjects'
    },
    VALIDATION_MSG: {
        REQUIRED:'This is Required'
    }
}