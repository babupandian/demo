import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appHighLight]',
  standalone: true
})
export class HighLightDirective {
  @Input() appHighLight = '';
  @Input() defaultColor = '';


  constructor(private el: ElementRef) { }

  ngOnInit(){
    this.highLight(this.defaultColor || '');
  }

  @HostListener('mouseleave') onMouseLeave(){
    this.highLight(this.defaultColor);
  }
  @HostListener('mouseenter') onMouseEnter(){
    this.highLight(this.appHighLight);
  }

  private highLight(color:string) {
    this.el.nativeElement.style.backgroundColor = color;
  }

}
