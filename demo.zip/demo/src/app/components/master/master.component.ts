import { Component, OnInit } from '@angular/core';
import { RolesComponent } from '../roles/roles.component';
import { DesignationComponent } from '../designation/designation.component';
import { CommonModule } from '@angular/common';
import { HighLightDirective } from '../../directives/high-light.directive';
import { CarService } from '../../services/car.service';


@Component({
  selector: 'app-master',
  standalone: true,
  imports: [RolesComponent,DesignationComponent, CommonModule, HighLightDirective],
  templateUrl: './master.component.html',
  styleUrl: './master.component.scss'
})
export class MasterComponent implements OnInit {

carNames:string[] = [];

currentComponent:string="";

changeTab(tabName: string) {
  this.currentComponent=tabName;
}

constructor( private carService: CarService){

}

ngOnInit(): void {
  this.carService.carNames$.subscribe((names) => {
    this.carNames = names;
  })
}

removeCar($index: any): void{ 
  this.carNames.splice($index, 1)
}


}
