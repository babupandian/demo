import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { APIResponseModel, IRole } from '../../model/interface/role';
import { CommonModule } from '@angular/common';
import { CarService } from '../../services/car.service';

@Component({
  selector: 'app-roles',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './roles.component.html',
  styleUrl: './roles.component.scss'
})
export class RolesComponent implements OnInit {
  carNames:any = [];
roleList: IRole[] = []; //for getting api in typescript we need to create interface any[] ->IRole[]
//constructor(private http: HttpClient){} --->old way deprecated -new way below
http = inject(HttpClient)
constructor( private carService: CarService){

}

ngOnInit(): void {
  // alert(1);
  this.getAllRoles()
}

onCarSumbit() {
  console.log(this.carNames);
  this.carService.addCarName(this.carNames);
 this.carNames = '';
}

getAllRoles() {
 this.http.get<APIResponseModel>("https://freeapi.miniprojectideas.com/api/ClientStrive/GetAllRoles").subscribe((res:APIResponseModel)=>{
this.roleList = res.data;
 })
}





















  /*firstName: string = "Angular tuts";
  angularVersion = "version 18";
  versionNumber:number = 18;
  isActive:boolean = false;
  currentDate:Date = new Date();
  inputType:string ="radio"; //checkbox/button
  selectedState:string='';

showWelcomeAlert(){
  alert("Welcome to angular");
}

  showMessage(message:string) {
alert(message);
  }*/



}
