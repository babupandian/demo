import { Component, inject, OnInit } from '@angular/core';
import { MasterService } from '../../services/master.service';
import { APIResponseModel, IDesignation } from '../../model/interface/role';

@Component({
  selector: 'app-designation',
  standalone: true,
  imports: [],
  templateUrl: './designation.component.html',
  styleUrl: './designation.component.scss'
})
export class DesignationComponent implements OnInit {
masterService = inject(MasterService);
designationList: IDesignation[]=[]; //it should be in top before inject
isLoader:boolean = true;

ngOnInit(): void {//we can subscribe here from master service, this function returning observable type of data
  //any function which is returning observable we can subscribe
  this.masterService.getDesignation().subscribe((result: APIResponseModel) =>{
this.designationList = result.data;
this.isLoader = false;
  },error=>{
    alert("API ERROR");
    this.isLoader = false;
  })
}

}

