import { Component, inject, OnInit } from '@angular/core';
import { Client } from '../../model/class/Clients';
import { FormsModule } from '@angular/forms';
import { ClientService } from '../../services/client.service';
import { APIResponseModel } from '../../model/interface/role';
import { AsyncPipe, DatePipe, UpperCasePipe } from '@angular/common';
import { Observable } from 'rxjs';
import { AlertComponent } from '../../reusableComponent/alert/alert.component';
import { MyButttonComponent } from '../../reusableComponent/my-buttton/my-buttton.component';

@Component({
  selector: 'app-client',
  standalone: true,
  imports: [FormsModule, UpperCasePipe, DatePipe, AsyncPipe, AlertComponent, MyButttonComponent],
  templateUrl: './client.component.html',
  styleUrl: './client.component.scss'
})
export class ClientComponent implements OnInit {
currentDate: Date = new Date();

clientObj:Client = new Client();
clientList: Client[]=[];

//ASYNC PIPE EXAMPLE - wrever we create observable try to add dollar $ at the end its naming standard
//we are not going to subscribe here, directly subscribe in html 
userList$: Observable<any> = new Observable<any>;

clientService = inject(ClientService);

ngOnInit(): void {
  this.loadClient();
  this.userList$ = this.clientService.getAllUser();
}

loadClient(){
this.clientService.getAllClients().subscribe((res:APIResponseModel)=>{
  this.clientList=res.data;
})
}

onSaveClient(data: string) {
  debugger;
this.clientService.addUpdate(this.clientObj).subscribe((res:APIResponseModel)=>{
  if(res.result) {
    alert("Success client create");
    this.loadClient();
    this.clientObj = new Client(); //it will call constructor & reinitalize
  }  else {
    alert(res.message);
  }
})

}

onEdit(data: Client) {
  this.clientObj = data;
}

onDelete(id:number) {
  const isDelete = confirm("Are u  sure want to delete?");
  if(isDelete) {
    this.clientService.deleteClientById(id).subscribe((res:APIResponseModel)=>{
      if(res.result) {
        alert("delete client");
        this.loadClient();
        
      }  else {
        alert(res.message);
      }
    })
  }

}

}
